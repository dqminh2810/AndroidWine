package org.o7planning.myapplication;

import org.o7planning.myapplication.databinding.ActivityMainBinding;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;

import java.util.ArrayList;


public final class MainActivity extends AppCompatActivity {
    private RelativeLayout mRelativeLayout;
    private ListView listView;
    private ArrayList<Vin> arrVin;
    private CustomAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mRelativeLayout = (RelativeLayout) findViewById(R.id.main);
        listView = (ListView) findViewById(R.id.lv_Vin);
        setListViewAdapter();
        createVinList();
    }

    private void setListViewAdapter() {
        arrVin = new ArrayList<Vin>();
        adapter = new CustomAdapter(this,R.layout.row_listview,arrVin, mRelativeLayout);
        listView.setAdapter(adapter);
    }
    private void createVinList() {
        Vin vin1 = new Vin("Chateau tour la verite", "AOC Bordeaux", "raisin", "bordeaux", Color.RED);
        Vin vin2 = new Vin("Chateau tour la verite", "AOC Bordeaux", "raisin", "bordeaux", Color.rgb(246,1,229) );
        Vin vin3 = new Vin("Chateau tour la verite", "AOC Bordeaux", "raisin", "bordeaux", Color.WHITE );
        Vin vin4 = new Vin("Chateau tour la verite", "AOC Bordeaux", "raisin", "nantes", Color.RED );

        arrVin.add(vin1);
        arrVin.add(vin2);
        arrVin.add(vin3);
        arrVin.add(vin4);
    }


}
