package org.o7planning.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import org.o7planning.myapplication.Vin;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by dqminh on 18/01/2018.
 */

public class CustomAdapter extends ArrayAdapter<Vin>{

    private RelativeLayout mRelativeLayout;
    private Activity activity;
    private Context context;
    private int resource;
    private List<Vin> arrVin;

    private Spinner cepageSpinner, regionSpinner, couleurSpinner;
    private Button mButton, popupButton;
    private EditText mNom, mAppellation;

    public CustomAdapter(Activity activity, int resource, ArrayList<Vin> arrContact, RelativeLayout mRelativeLayout) {
        super(activity, resource, arrContact);
        this.activity = activity;
        this.resource = resource;
        this.arrVin = arrContact;
        this.mRelativeLayout=mRelativeLayout;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final ViewHolder viewHolder;

        if (convertView == null) {
            convertView = LayoutInflater.from(activity).inflate(R.layout.row_listview, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.tvNom = (TextView) convertView.findViewById(R.id.tvNom);
            viewHolder.tvAppellation = (TextView) convertView.findViewById(R.id.tvAppellation);
            viewHolder.tvCepage = (TextView) convertView.findViewById(R.id.tvCepage);
            viewHolder.tvRegion = (TextView) convertView.findViewById(R.id.tvRegion);
            viewHolder.tvCouleur = (TextView) convertView.findViewById(R.id.tvCouleur);
            viewHolder.btnClick =(Button) convertView.findViewById(R.id.btnClick);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        Vin vin = arrVin.get(position);
        if(vin.getCouleur()==Color.RED){
            viewHolder.tvCouleur.setBackgroundColor(Color.RED);
        }else if(vin.getCouleur()==Color.WHITE){
            viewHolder.tvCouleur.setBackgroundColor(Color.WHITE);
        }else if(vin.getCouleur()==Color.rgb(246,1,229)){
            viewHolder.tvCouleur.setBackgroundColor(Color.rgb(246,1,229));
        }else{
            viewHolder.tvCouleur.setBackgroundColor(vin.getCouleur());
        }

        viewHolder.tvCouleur.setText(String.valueOf(position+1));
        viewHolder.tvNom.setText(vin.getNom());
        viewHolder.tvAppellation.setText(vin.getAppellation());
        viewHolder.tvCepage.setText(vin.getCepage());
        viewHolder.tvRegion.setText(vin.getRegion());

        viewHolder.btnClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Initialize a new instance of LayoutInflater service
                LayoutInflater inflater = (LayoutInflater) activity.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
                View customView = inflater.inflate(R.layout.layout_addcave, null);
                final PopupWindow myPopup = new PopupWindow(
                        customView,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );
                myPopup.showAtLocation(mRelativeLayout, Gravity.CENTER, 0, 0);
                myPopup.setFocusable(true);
                myPopup.update();

                //Handle POPUP
                mNom = (EditText) customView.findViewById(R.id.etNomVin);
                mAppellation = (EditText) customView.findViewById(R.id.appellationVinEditText);
                cepageSpinner = (Spinner) customView.findViewById(R.id.cepageSpinner);
                regionSpinner = (Spinner) customView.findViewById(R.id.regionSpinner);
                couleurSpinner = (Spinner) customView.findViewById(R.id.couleurSpinner);
                popupButton = (Button) customView.findViewById(R.id.validButton);

                final ArrayAdapter<CharSequence> cepageAdapter = ArrayAdapter.createFromResource(activity,
                        R.array.cepages_array, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
                cepageAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
                cepageSpinner.setAdapter(cepageAdapter);

                ArrayAdapter<CharSequence> regionAdapter = ArrayAdapter.createFromResource(activity,
                        R.array.regions_array, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
                regionAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
                regionSpinner.setAdapter(regionAdapter);

                ArrayAdapter<CharSequence> couleurAdapter = ArrayAdapter.createFromResource(activity,
                        R.array.couleurs_array, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
                couleurAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
                couleurSpinner.setAdapter(couleurAdapter);
                popupButton.setOnClickListener(new Button.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        viewHolder.tvNom.setText(mNom.getText().toString());
                        viewHolder.tvAppellation.setText(mAppellation.getText().toString());
                        viewHolder.tvCepage.setText(cepageSpinner.getSelectedItem().toString());
                        viewHolder.tvRegion.setText(regionSpinner.getSelectedItem().toString());
                        String couleur=couleurSpinner.getSelectedItem().toString();
                        if(couleur.equals("Rouge")){
                            viewHolder.tvCouleur.setBackgroundColor(Color.RED);
                        }else if(couleur.equals("Blanc")){
                            viewHolder.tvCouleur.setBackgroundColor(Color.WHITE);
                        }else if(couleur.equals("Rosé")){
                            viewHolder.tvCouleur.setBackgroundColor(Color.rgb(246,1,229));
                        }
                        myPopup.dismiss();
                    }
                });
            }

        });
        return convertView;
    }


}
