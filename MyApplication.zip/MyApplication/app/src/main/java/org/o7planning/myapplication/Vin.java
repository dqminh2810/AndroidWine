package org.o7planning.myapplication;

import org.o7planning.myapplication.databinding.ActivityMainBinding;
/**
 * Created by dqminh on 16/01/2018.
 */
public class Vin {
    protected String nom, appellation, cepage, region;
    protected int couleur;

    public String getAppellation() {
        return appellation;
    }

    public void setAppellation(String appellation) {
        this.appellation = appellation;
    }

    public String getCepage() {
        return cepage;
    }

    public void setCepage(String cepage) {
        this.cepage = cepage;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public int getCouleur() {
        return couleur;
    }

    public void setCouleur(int couleur) {
        this.couleur = couleur;
    }

    public Vin(String nom, String appellation, String cepage, String region, int couleur) {
        this.nom = nom;
        this.appellation=appellation;
        this.cepage=cepage;
        this.region=region;
        this.couleur=couleur;
    }
    public String getNom() {
        return this.nom;
    }


    public void setNom(String nom) {
        this.nom = nom;
    }

}