package org.o7planning.myapplication;

import android.widget.Button;
import android.widget.TextView;

/**
 * Created by dqminh on 18/01/2018.
 */

public class ViewHolder {
    TextView tvNom, tvAppellation, tvCepage, tvRegion, tvCouleur;
    Button btnClick;
}
